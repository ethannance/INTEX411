﻿namespace AuthLab2.Models
{
    public class ProductPrediction
    {
        public Product Product { get; set; }
        public string Prediction { get; set; } // Assuming this is the predicted Category
    }
}

